
// Question 4: Check if Binary Tree is BST
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int v) : data(v), left(NULL), right(NULL) {}
};

bool isBSTUtil(Node* root, int minv, int maxv) {
    if (!root) return true;
    if (root->data <= minv || root->data >= maxv) return false;
    return isBSTUtil(root->left, minv, root->data) &&
           isBSTUtil(root->right, root->data, maxv);
}

bool isBST(Node* root) {
    return isBSTUtil(root, -1000000, 1000000);
}

int main() {
    Node* root = new Node(10);
    root->left = new Node(5);
    root->right = new Node(20);

    cout << (isBST(root) ? "BST" : "Not BST");
}
