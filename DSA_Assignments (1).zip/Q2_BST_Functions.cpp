
// Question 2: BST Special Functions
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int v) : data(v), left(NULL), right(NULL) {}
};

Node* insert(Node* root, int key) {
    if (!root) return new Node(key);
    if (key < root->data) root->left = insert(root->left, key);
    else if (key > root->data) root->right = insert(root->right, key);
    return root;
}

Node* searchRec(Node* root, int key) {
    if (!root || root->data == key) return root;
    if (key < root->data) return searchRec(root->left, key);
    return searchRec(root->right, key);
}

Node* searchNonRec(Node* root, int key) {
    while (root && root->data != key) {
        root = (key < root->data) ? root->left : root->right;
    }
    return root;
}

Node* minNode(Node* root) {
    while (root && root->left) root = root->left;
    return root;
}

Node* maxNode(Node* root) {
    while (root && root->right) root = root->right;
    return root;
}

Node* inorderSuccessor(Node* root, int key) {
    Node* curr = searchRec(root, key);
    if (!curr) return NULL;
    if (curr->right) return minNode(curr->right);
    Node* succ = NULL;
    while (root) {
        if (key < root->data) { succ = root; root = root->left; }
        else if (key > root->data) root = root->right;
        else break;
    }
    return succ;
}

Node* inorderPredecessor(Node* root, int key) {
    Node* curr = searchRec(root, key);
    if (!curr) return NULL;
    if (curr->left) return maxNode(curr->left);
    Node* pred = NULL;
    while (root) {
        if (key > root->data) { pred = root; root = root->right; }
        else if (key < root->data) root = root->left;
        else break;
    }
    return pred;
}

int main() {
    Node* root = NULL;
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 70);

    cout << "Search Recursive: " << (searchRec(root, 70) ? "Found" : "Not Found");
}
